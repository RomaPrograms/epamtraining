DROP DATABASE IF EXISTS lakes_paradise_db;
