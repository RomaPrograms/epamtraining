/**
 * package contains classes which process admin actions.
 */
package by.training.lakes_paradise.action.admin;
