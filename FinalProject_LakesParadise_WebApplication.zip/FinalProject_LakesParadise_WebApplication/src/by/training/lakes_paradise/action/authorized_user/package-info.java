/**
 * package contains classes which process authorized user actions.
 */
package by.training.lakes_paradise.action.authorized_user;
