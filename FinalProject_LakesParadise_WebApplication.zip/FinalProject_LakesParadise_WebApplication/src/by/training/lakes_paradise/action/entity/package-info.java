/**
 * package contains entity action classes for handling user requests.
 */
package by.training.lakes_paradise.action.entity;
