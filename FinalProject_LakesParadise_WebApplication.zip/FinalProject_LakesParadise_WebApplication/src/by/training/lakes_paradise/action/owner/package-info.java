/**
 * package contains classes which process owner actions.
 */
package by.training.lakes_paradise.action.owner;
