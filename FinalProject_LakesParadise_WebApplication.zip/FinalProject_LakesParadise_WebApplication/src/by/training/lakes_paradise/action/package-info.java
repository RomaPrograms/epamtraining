/**
 * package contains classes which process user actions.
 */
package by.training.lakes_paradise.action;
