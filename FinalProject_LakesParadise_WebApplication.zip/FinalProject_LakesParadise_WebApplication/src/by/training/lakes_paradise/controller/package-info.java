/**
 * package contains servlet class which process every user action.
 */
package by.training.lakes_paradise.controller;
