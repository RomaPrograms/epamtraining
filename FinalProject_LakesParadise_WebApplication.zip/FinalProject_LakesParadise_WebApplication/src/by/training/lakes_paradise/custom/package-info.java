/**
 * package contains user-defined tags.
 */
package by.training.lakes_paradise.custom;
