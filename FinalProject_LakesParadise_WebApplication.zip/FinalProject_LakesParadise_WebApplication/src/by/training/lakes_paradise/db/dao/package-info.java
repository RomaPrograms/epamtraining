/**
 * package contains interfaces for working with Database.
 */
package by.training.lakes_paradise.db.dao;
