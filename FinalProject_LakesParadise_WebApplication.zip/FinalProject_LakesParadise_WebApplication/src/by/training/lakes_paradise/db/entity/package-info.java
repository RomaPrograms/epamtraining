/**
 * package contains all entity classes.
 */
package by.training.lakes_paradise.db.entity;
