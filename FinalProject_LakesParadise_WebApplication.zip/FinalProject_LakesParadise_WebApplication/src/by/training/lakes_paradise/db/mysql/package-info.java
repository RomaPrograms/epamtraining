/**
 * package contains classes that realize working with Database.
 */
package by.training.lakes_paradise.db.mysql;
