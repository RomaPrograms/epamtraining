/**
 * package contains exceptions.
 */
package by.training.lakes_paradise.exception;
