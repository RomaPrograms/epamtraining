/**
 * package contains filters for processing every user request before it will
 * be executed.
 */
package by.training.lakes_paradise.filter;
