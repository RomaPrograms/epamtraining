package by.training.lakes_paradise.service;

/**
 * Interface without methods simply to pick out a special group of classes.
 */
public interface Service {
}
