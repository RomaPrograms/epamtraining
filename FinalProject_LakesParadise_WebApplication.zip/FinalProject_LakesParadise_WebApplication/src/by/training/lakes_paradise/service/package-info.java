/**
 * package contains classes for additional layer between user and database.
 */
package by.training.lakes_paradise.service;
