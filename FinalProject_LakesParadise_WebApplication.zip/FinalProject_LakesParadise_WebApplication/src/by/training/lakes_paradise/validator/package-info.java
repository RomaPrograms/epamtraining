/**
 * package contains validator classes for validation some user requests.
 */
package by.training.lakes_paradise.validator;
