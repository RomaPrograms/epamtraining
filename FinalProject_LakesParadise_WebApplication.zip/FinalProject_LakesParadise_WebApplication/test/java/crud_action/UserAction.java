package crud_action;

public class UserAction {
}
