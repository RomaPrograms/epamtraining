/**
 * package with entity classes and interfaces.
 */
package by.training.informhandling.entity;
