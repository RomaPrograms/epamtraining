/**
 * package contains operations for calculating bit expression.
 */
package by.training.informhandling.parsing.parsingexpression.bitoperation;
