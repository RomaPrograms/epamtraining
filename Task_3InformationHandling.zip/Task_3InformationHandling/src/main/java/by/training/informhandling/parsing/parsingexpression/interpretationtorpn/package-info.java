/**
 * package contain classes for calculating bit expressions.
 */
package by.training.informhandling.parsing.parsingexpression.interpretationtorpn;
