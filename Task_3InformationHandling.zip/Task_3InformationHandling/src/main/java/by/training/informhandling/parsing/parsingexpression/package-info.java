/**
 * package contains packages for calculating bit operations.
 */
package by.training.informhandling.parsing.parsingexpression;
