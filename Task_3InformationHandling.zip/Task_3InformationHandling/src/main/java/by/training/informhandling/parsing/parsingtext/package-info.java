/**
 * package contains classes for parsing text.
 */
package by.training.informhandling.parsing.parsingtext;
