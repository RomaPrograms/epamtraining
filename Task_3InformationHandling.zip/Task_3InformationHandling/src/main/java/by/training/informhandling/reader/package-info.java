/**
 * package that contains classes for reading information from different sources.
 */
package by.training.informhandling.reader;
