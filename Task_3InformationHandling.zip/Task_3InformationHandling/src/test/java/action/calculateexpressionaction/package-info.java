/**
 * package contains tests for calculating expressions.
 */
package action.calculateexpressionaction;
