/**
 * package contains classes for parsing text
 */
package action.parsingaction;
