/**
 * package contains classes for reading from file.
 */
package action.readingaction;
