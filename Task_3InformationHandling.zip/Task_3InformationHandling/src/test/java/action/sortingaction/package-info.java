/**
 * package contains classes for sorting text.
 */
package action.sortingaction;
