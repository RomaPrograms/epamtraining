/**
 * package that contains entity classes for our program.
 */
package by.training.webparsing.entity;
