/**
 * package that contains exception classes.
 */
package by.training.webparsing.exception;
