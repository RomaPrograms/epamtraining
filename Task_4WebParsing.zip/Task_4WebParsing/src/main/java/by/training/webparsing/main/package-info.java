/**
 * package that contains class with {@code main()} method.
 */
package by.training.webparsing.main;
