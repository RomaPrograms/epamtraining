/**
 * package that contains class for using different languages.
 */
package by.training.webparsing.propertymanager;
